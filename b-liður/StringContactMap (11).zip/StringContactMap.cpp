#include "StringContactMap.h"
#include "Hash.h"

#include <algorithm>

using namespace std;

StringContactMap::StringContactMap(int initial_capacity)
{
    capacity = initial_capacity;
    map = new ListPtr[capacity];
    for(int i = 0; i < capacity; i++)
    {
        map[i] = new ContactList;
    }
    count = 0;
}

StringContactMap::~StringContactMap()
{
    for(int i = 0; i < capacity; i++)
    {
        delete map[i];
    }

    delete [] map;
}

void StringContactMap::load_check()
{
    if((count / static_cast<double>(capacity)) > MAX_LOAD)
    {
        rebuild();
    }
}

void StringContactMap::rebuild()
{
    ListPtr *old_map = map;
    int old_capacity = capacity;

    capacity *= 2;
    map = new ListPtr[capacity];

    for(int i = 0; i < capacity; i++)
    {
        map[i] = new ContactList;
    }

    vector<StringContactPair> old_list;

    //int hash_key;

    count = 0;

    for(int i = 0; i < old_capacity; i++)
    {

        old_list = old_map[i]->to_vector();

        for(unsigned int j = 0; j < old_list.size(); j++)
        {
            add(old_list[j].key, old_list[j].value);
        }

        old_list.clear();
        delete old_map[i];
    }

    delete [] old_map;
}

int StringContactMap::size() const
{
	return count;
}

bool StringContactMap::empty() const
{
	return count == 0;
}

vector<Contact> StringContactMap::all_contacts() const
{
	vector<Contact> vec;
	for(int i = 0; i < capacity; i++)
    {
        map[i]->get_contacts(vec);
    }
	return vec;
}

void StringContactMap::add(string key, Contact value)
{
    load_check();

    int hash_key = hash(key) % capacity;

    if(map[hash_key]->add(key, value))
    {
        ++count;
    }

}

void StringContactMap::remove(string key)
{
    int hash_key = hash(key) % capacity;

    if(map[hash_key]->remove(key))
    {
        --count;
    }

}

bool StringContactMap::contains(string key) const
{
    int hash_key = hash(key) % capacity;

    return map[hash_key]->contains(key);
}

Contact StringContactMap::get(string key) const
{
	int hash_key = hash(key) % capacity;

	return map[hash_key]->get(key);
}

vector<Contact> StringContactMap::prefix_search(string prefix) const
{
	return vector<Contact>();
}

// Optionally implement.
ostream& operator <<(ostream& out, const StringContactMap& map)
{
	return out;
}

