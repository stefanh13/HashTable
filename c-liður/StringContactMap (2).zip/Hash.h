#ifndef HASH_H
#define HASH_H

#include <string>

using namespace std;

unsigned int hash(string s);

#endif
