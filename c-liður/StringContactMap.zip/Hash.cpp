#include "Hash.h"

unsigned int hash(string s)
{
	return 1337;
}
