#ifndef KEYEXCEPTION_H
#define KEYEXCEPTION_H

class KeyException { };

#endif
